CREATE TABLE Professor (
    ProfID INT PRIMARY KEY, 
    ProfName VARCHAR(100) NOT NULL
);

CREATE TABLE Classroom (
    RoomNumber INT PRIMARY KEY, 
    Seats INT NOT NULL 
);

CREATE TABLE Subject (
    SubjectID INT PRIMARY KEY, 
    SubjectName VARCHAR(100) NOT NULL 
);

CREATE TABLE Lecture (
    LectureID INT PRIMARY KEY,
    ProfID INT NOT NULL, 
    RoomNumber INT NOT NULL, 
    SubjectID INT NOT NULL, 
    LectureTime DATETIME NOT NULL, 
    FOREIGN KEY (ProfID) REFERENCES Professor(ProfID) ON DELETE CASCADE,
    FOREIGN KEY (RoomNumber) REFERENCES Classroom(RoomNumber) ON DELETE CASCADE,
    FOREIGN KEY (SubjectID) REFERENCES Subject(SubjectID) ON DELETE CASCADE
);

CREATE TABLE Student (
    StudentID INT PRIMARY KEY, 
    StudentName VARCHAR(100) NOT NULL 
);

CREATE TABLE Enrollment (
    EnrollmentDate DATE NOT NULL, 
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID) ON DELETE CASCADE,
    FOREIGN KEY (SubjectID) REFERENCES Subject(SubjectID) ON DELETE CASCADE
);

CREATE TABLE Cancellation (
    CancellationDate DATE NOT NULL,
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID) ON DELETE CASCADE,
    FOREIGN KEY (SubjectID) REFERENCES Subject(SubjectID) ON DELETE CASCADE
);
